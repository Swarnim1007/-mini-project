/*
Author:		swarnim
Roll No.: 	MT2023029
Date: 		18/10/2023
*/

void welcome_screen(){
	system("clear");
	printf("Developed by Swarnim (MT2023029) \n");
	printf("\nWelcome to Academia\n");
	sleep(1);
	printf("\nConnecting to server\n");
	sleep(1);
	system("clear");
	printf("Developed by Swarnim (MT2023029) \n");
	printf("\nWelcome to Academia\n");
	printf("\nConnecting to server.\n");
	sleep(1);
	system("clear");
	printf("Developed by Swarnim (MT2023029) \n");
	printf("\nWelcome to Academia\n");
	printf("\nConnecting to server.\n");
	sleep(1);
	system("clear");
	printf("Developed by Swarnim (MT2023029) \n");
	printf("\nWelcome to Academia\n");
	printf("\nConnecting to server.\n");
	sleep(1);
	system("clear");
}
